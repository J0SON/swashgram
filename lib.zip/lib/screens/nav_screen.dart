import 'package:flutter/material.dart';
import 'package:app/screens/screens.dart';

class NavScreen extends StatefulWidget {
  @override
  _NavScreenState createState() => _NavScreenState();
}

class _NavScreenState extends State<NavScreen> {
  int _selectedIndex = 0;
  void _navigateBottomBar(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  final List<Widget> _pages = [
    HomeScreen(),
    Center(child: Text('follow')),
    Center(child: Text('message')),
    Center(child: Text('notification')),
    Center(child: Text('userAccount')),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _navigateBottomBar,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            label: 'Home',
            activeIcon: Icon(Icons.home),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_add_alt),
            label: 'follow',
            activeIcon: Icon(Icons.person_add_alt),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.message_outlined),
            label: 'message',
            activeIcon: Icon(Icons.message_outlined),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_active),
            label: 'notification',
            activeIcon: Icon(Icons.notifications_active),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'userProfile',
            activeIcon: Icon(Icons.person),
          ),
        ],
      ),
    );
  }
}
